﻿
    class Circle
    {
    public double Center { get; set; }
    public double Radius { get; set; }
    }

