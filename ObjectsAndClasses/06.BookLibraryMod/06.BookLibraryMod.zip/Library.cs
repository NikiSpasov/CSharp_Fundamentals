﻿using System.Collections.Generic;


class Library
{
    public string Name { get; set; }
    public List<Books> Books { get; set; }
}
